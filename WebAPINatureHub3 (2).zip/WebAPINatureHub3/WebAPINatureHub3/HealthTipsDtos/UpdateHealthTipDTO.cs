﻿namespace WebAPINatureHub3.HealthTipsDtos
{
    public class UpdateHealthTipDTO
    {
        public int TipId { get; set; }
        public string TipTitle { get; set; } = null!;
        public string? TipDescription { get; set; }
        public int CategoryId { get; set; }
    }
}
