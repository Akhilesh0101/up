﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebAPINatureHub3.HealthTipsDtos;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HealthTipsController : ControllerBase
    {
        private readonly NatureHub3Context _context;

        public HealthTipsController(NatureHub3Context context)
        {
            _context = context;
        }

        // POST: api/HealthTips
        [HttpPost]
        public async Task<IActionResult> CreateHealthTip([FromForm] CreateHealthTipDTO createHealthTipDTO, IFormFile file)
        {
            // Validate fields
            if (file == null || file.Length == 0)
            {
                return BadRequest("No image provided.");
            }
            if (string.IsNullOrWhiteSpace(createHealthTipDTO.TipTitle))
                return BadRequest("Tip title is required.");

            // Convert file to byte array
            byte[] fileData;
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                fileData = memoryStream.ToArray();
            }

            // Create the health tip and save to database
            var healthTip = new HealthTip
            {
                TipTitle = createHealthTipDTO.TipTitle,
                TipDescription = createHealthTipDTO.TipDescription,
                CategoryId = createHealthTipDTO.CategoryId,
                HealthTipsimg = fileData // Store the image as byte array
            };

            _context.HealthTips.Add(healthTip);
            await _context.SaveChangesAsync();

            // Return the created health tip in the ReadHealthTipDTO format
            var healthTipDTO = new ReadHealthTipDTO
            {
                TipId = healthTip.TipId,
                TipTitle = healthTip.TipTitle,
                HealthTipsimg = healthTip.HealthTipsimg,
                TipDescription = healthTip.TipDescription,
                CategoryId = healthTip.CategoryId,
            };

            return CreatedAtAction(nameof(GetHealthTip), new { id = healthTip.TipId }, healthTipDTO);
        }

        // GET: api/HealthTips/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetHealthTip(int id)
        {
            var healthTip = await _context.HealthTips.FindAsync(id);
            if (healthTip == null)
            {
                return NotFound("Health tip not found.");
            }

            var healthTipDTO = new ReadHealthTipDTO
            {
                TipId = healthTip.TipId,
                TipTitle = healthTip.TipTitle,
                TipDescription = healthTip.TipDescription,
                HealthTipsimg = healthTip.HealthTipsimg,
                CategoryId = healthTip.CategoryId,
            };

            return Ok(healthTipDTO);
        }

        // PUT: api/HealthTips/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateHealthTip(int id, [FromForm] UpdateHealthTipDTO updateHealthTipDTO, IFormFile? file)
        {
            var healthTip = await _context.HealthTips.FindAsync(id);
            if (healthTip == null)
            {
                return NotFound("Health tip not found.");
            }

            // Update health tip data from DTO
            healthTip.TipTitle = updateHealthTipDTO.TipTitle;
            healthTip.TipDescription = updateHealthTipDTO.TipDescription;
            healthTip.CategoryId = updateHealthTipDTO.CategoryId;

            // If a new image is uploaded, update it
            if (file != null && file.Length > 0)
            {
                byte[] fileData;
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    fileData = memoryStream.ToArray();
                }
                healthTip.HealthTipsimg = fileData;  // Update health tip image
            }

            await _context.SaveChangesAsync();
            return Ok(new { Message = "Health tip updated successfully." });
        }

        // DELETE: api/HealthTips/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHealthTip(int id)
        {
            var healthTip = await _context.HealthTips.FindAsync(id);
            if (healthTip == null)
            {
                return NotFound("Health tip not found.");
            }

            _context.HealthTips.Remove(healthTip);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Health tip deleted successfully." });
        }

        // GET: api/HealthTips
        [HttpGet]
        public async Task<IActionResult> GetAllHealthTips()
        {
            var healthTips = await _context.HealthTips.ToListAsync();
            if (healthTips == null || !healthTips.Any())
            {
                return NotFound("No health tips found.");
            }

            var healthTipDTOs = healthTips.Select(healthTip => new ReadHealthTipDTO
            {
                TipId = healthTip.TipId,
                TipTitle = healthTip.TipTitle,
                HealthTipsimg = healthTip.HealthTipsimg,
                TipDescription = healthTip.TipDescription,
                CategoryId = healthTip.CategoryId,
            }).ToList();

            return Ok(healthTipDTOs);
        }
    }
}
